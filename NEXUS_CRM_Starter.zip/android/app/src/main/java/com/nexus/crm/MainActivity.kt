package com.nexus.crm

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    private val navy = Color.rgb(16, 24, 47)
    private val blue = Color.rgb(49, 87, 213)
    private val ink = Color.rgb(30, 39, 59)
    private val muted = Color.rgb(112, 122, 145)
    private val pale = Color.rgb(244, 246, 251)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = navy
        window.navigationBarColor = navy
        setContentView(buildScreen())
    }

    private fun buildScreen(): LinearLayout {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(pale)
            setPadding(dp(20), dp(28), dp(20), dp(20))
            layoutParams = ViewGroup.LayoutParams(-1, -1)
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(22), dp(20), dp(24))
            setBackgroundColor(navy)
        }
        header.addView(label("NEXUS CRM", 13, Color.rgb(174, 192, 255), true))
        header.addView(label("Boshqaruv paneli", 25, Color.WHITE, true).apply {
            setPadding(0, dp(8), 0, dp(5))
        })
        header.addView(label("Mijozlar va arizalarni yagona tizimda boshqaring", 13, Color.rgb(205, 213, 231), false))
        root.addView(header, LinearLayout.LayoutParams(-1, -2))

        root.addView(label("Asosiy bo‘limlar", 19, ink, true).apply {
            setPadding(0, dp(25), 0, dp(12))
        })
        addCard(root, "Mijozlar", "Mijozlarni ro‘yxatga olish va ma’lumotlarini ko‘rish", "01")
        addCard(root, "Arizalar", "Yangi arizalar va ularning holatini boshqarish", "02")
        addCard(root, "Tasdiqlash", "Menejer ko‘rib chiqishi va qarorlar", "03")
        addCard(root, "Hisobotlar", "Faoliyat va bajarilgan amallar tarixi", "04")

        root.addView(label("Demo interfeys · Backend keyingi bosqichda ulanadi", 11, muted, false).apply {
            gravity = Gravity.CENTER
            setPadding(0, dp(18), 0, 0)
        })
        return root
    }

    private fun addCard(root: LinearLayout, title: String, description: String, number: String) {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(Color.WHITE)
            setPadding(dp(16), dp(15), dp(16), dp(15))
            elevation = dp(2).toFloat()
        }
        val badge = TextView(this).apply {
            text = number
            textSize = 13f
            setTextColor(blue)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setBackgroundColor(Color.rgb(235, 240, 255))
            layoutParams = LinearLayout.LayoutParams(dp(42), dp(42))
        }
        card.addView(badge)
        val texts = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), 0, 0, 0)
        }
        texts.addView(label(title, 16, ink, true))
        texts.addView(label(description, 12, muted, false).apply {
            setPadding(0, dp(4), 0, 0)
        })
        card.addView(texts, LinearLayout.LayoutParams(0, -2, 1f))
        val params = LinearLayout.LayoutParams(-1, -2)
        params.bottomMargin = dp(11)
        root.addView(card, params)
    }

    private fun label(textValue: String, size: Int, color: Int, bold: Boolean): TextView = TextView(this).apply {
        text = textValue
        textSize = size.toFloat()
        setTextColor(color)
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
