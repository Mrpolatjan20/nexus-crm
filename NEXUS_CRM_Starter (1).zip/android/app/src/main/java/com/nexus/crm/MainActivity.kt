package com.nexus.crm

import android.app.Activity
import android.app.AlertDialog
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.graphics.pdf.PdfDocument
import android.graphics.Paint
import android.graphics.Canvas
import android.provider.OpenableColumns
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.content.ContentValues
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*

private object Palette {
    val navy = Color.rgb(15, 27, 54); val blue = Color.rgb(48, 91, 220)
    val bg = Color.rgb(244, 246, 251); val ink = Color.rgb(28, 39, 62)
    val muted = Color.rgb(111, 122, 145); val green = Color.rgb(25, 150, 105)
    val red = Color.rgb(205, 65, 75); val line = Color.rgb(225, 230, 239)
}

data class Session(val username: String, val fullName: String, val role: String)

class CrmDb(context: Activity) : SQLiteOpenHelper(context, "nexus_crm.db", null, 2) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE users(id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT UNIQUE, password TEXT, full_name TEXT, role TEXT, active INTEGER DEFAULT 1)")
        db.execSQL("CREATE TABLE customers(id INTEGER PRIMARY KEY AUTOINCREMENT, full_name TEXT, phone TEXT, note TEXT, created_at TEXT DEFAULT CURRENT_TIMESTAMP)")
        db.execSQL("CREATE TABLE applications(id INTEGER PRIMARY KEY AUTOINCREMENT, customer_id INTEGER, title TEXT, amount TEXT, status TEXT DEFAULT 'Yangi', note TEXT, created_at TEXT DEFAULT CURRENT_TIMESTAMP)")
        db.execSQL("CREATE TABLE audit(id INTEGER PRIMARY KEY AUTOINCREMENT, actor TEXT, action TEXT, detail TEXT, created_at TEXT DEFAULT CURRENT_TIMESTAMP)")
        db.execSQL("CREATE TABLE chat(id INTEGER PRIMARY KEY AUTOINCREMENT, sender TEXT, role TEXT, message TEXT, created_at TEXT DEFAULT CURRENT_TIMESTAMP)")
        db.execSQL("CREATE TABLE documents(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, uri TEXT, uploaded_by TEXT, created_at TEXT DEFAULT CURRENT_TIMESTAMP)")
        val users = listOf(
            arrayOf("operator", "123456", "Operator Demo", "OPERATOR"),
            arrayOf("manager", "123456", "Menejer Demo", "MANAGER"),
            arrayOf("admin", "123456", "Administrator", "ADMIN")
        )
        users.forEach { row ->
            val v = ContentValues(); v.put("username", row[0]); v.put("password", row[1]); v.put("full_name", row[2]); v.put("role", row[3]); db.insert("users", null, v)
        }
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        if (oldVersion < 2) {
            db.execSQL("CREATE TABLE IF NOT EXISTS chat(id INTEGER PRIMARY KEY AUTOINCREMENT, sender TEXT, role TEXT, message TEXT, created_at TEXT DEFAULT CURRENT_TIMESTAMP)")
            db.execSQL("CREATE TABLE IF NOT EXISTS documents(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, uri TEXT, uploaded_by TEXT, created_at TEXT DEFAULT CURRENT_TIMESTAMP)")
        }
    }
    fun log(actor: String, action: String, detail: String) {
        val v = ContentValues(); v.put("actor", actor); v.put("action", action); v.put("detail", detail); writableDatabase.insert("audit", null, v)
    }
}

class MainActivity : Activity() {
    private lateinit var db: CrmDb
    private var session: Session? = null
    private lateinit var root: LinearLayout
    private lateinit var content: LinearLayout
    private val pad by lazy { (16 * resources.displayMetrics.density).toInt() }
    private var language = "uz"
    private var pendingExport = ""
    private val REQ_FILE = 701
    private val REQ_EXPORT = 702

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        db = CrmDb(this)
        language = getSharedPreferences("nexus", MODE_PRIVATE).getString("language", "uz") ?: "uz"
        createNotificationChannel()
        window.statusBarColor = Palette.navy; window.navigationBarColor = Palette.navy
        showLogin()
    }

    private fun base(): LinearLayout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Palette.bg); layoutParams = ViewGroup.LayoutParams(-1, -1) }
    private fun text(s: String, size: Float = 14f, color: Int = Palette.ink, bold: Boolean = false): TextView = TextView(this).apply { text = s; textSize = size; setTextColor(color); if (bold) typeface = Typeface.DEFAULT_BOLD }
    private fun button(s: String, color: Int = Palette.blue, onClick: () -> Unit): Button = Button(this).apply { text = s; isAllCaps = false; setTextColor(Color.WHITE); setBackgroundTintList(android.content.res.ColorStateList.valueOf(color)); setOnClickListener { onClick() } }
    private fun field(hint: String): EditText = EditText(this).apply { this.hint = hint; textSize = 15f; setSingleLine(true); setPadding(pad, pad / 2, pad, pad / 2); background = android.graphics.drawable.GradientDrawable().apply { setColor(Color.WHITE); cornerRadius = 14f; setStroke(1, Palette.line) } }
    private fun scroll(): ScrollView = ScrollView(this).apply { isFillViewport = true }
    private fun showLogin() {
        session = null
        val page = base(); page.gravity = Gravity.CENTER; page.setPadding(pad * 1.3f.toInt(), pad, pad * 1.3f.toInt(), pad)
        val card = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(pad, pad * 2, pad, pad); background = android.graphics.drawable.GradientDrawable().apply { setColor(Color.WHITE); cornerRadius = 26f } }
        card.addView(NetworkLogoView(this), LinearLayout.LayoutParams(pad * 4, pad * 4).apply { gravity = Gravity.CENTER })
        card.addView(text("NEXUS CRM", 27f, Palette.navy, true).apply { gravity = Gravity.CENTER }); card.addView(text(if(language=="uz") "Korporativ mijozlar va arizalarni boshqarish" else "Управление клиентами и заявками", 13f, Palette.muted).apply { gravity=Gravity.CENTER; setPadding(0, pad / 2, 0, pad * 2) })
        val username = field("Login"); val password = field("Parol"); password.inputType = 129
        card.addView(username); card.addView(Space(this).apply { minimumHeight = pad }); card.addView(password)
        card.addView(button("Tizimga kirish") { login(username.text.toString().trim(), password.text.toString()) }.apply { setPadding(0, pad / 2, 0, pad / 2) })
        card.addView(text("Demo kirish ma’lumotlari", 12f, Palette.muted, true).apply { setPadding(0, pad, 0, 4) })
        card.addView(text("Operator: operator / 123456\nMenejer: manager / 123456\nAdmin: admin / 123456", 12f, Palette.muted))
        page.addView(card, LinearLayout.LayoutParams(-1, -2)); setContentView(page)
    }
    private fun login(u: String, p: String) {
        val c = db.readableDatabase.rawQuery("SELECT username, full_name, role FROM users WHERE username=? AND password=? AND active=1", arrayOf(u, p))
        if (!c.moveToFirst()) { c.close(); AlertDialog.Builder(this).setMessage("Login yoki parol noto‘g‘ri.").setPositiveButton("OK", null).show(); return }
        session = Session(c.getString(0), c.getString(1), c.getString(2)); c.close(); db.log(u, "LOGIN", "Tizimga kirdi"); showDashboard("Boshqaruv")
    }
    private fun showDashboard(tab: String) {
        val s = session ?: return
        root = base()
        val header = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(pad, pad, pad, pad); setBackgroundColor(Palette.navy) }
        val brand = LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER_VERTICAL }
        brand.addView(NetworkLogoView(this), LinearLayout.LayoutParams(pad*2, pad*2))
        brand.addView(text("NEXUS CRM", 15f, Color.WHITE, true).apply { setPadding(pad/2,0,0,0) }, LinearLayout.LayoutParams(0,-2,1f))
        brand.addView(button(if(language=="uz") "UZ | RU" else "RU | UZ", Color.rgb(70,90,140)) { language=if(language=="uz") "ru" else "uz"; getSharedPreferences("nexus",MODE_PRIVATE).edit().putString("language",language).apply(); showDashboard(tab) })
        header.addView(brand); header.addView(text(tabLabel(tab), 23f, Color.WHITE, true).apply { setPadding(0, 5, 0, 4) }); header.addView(text("${s.fullName}  ·  ${roleName(s.role)}", 12f, Color.rgb(211, 219, 237)))
        root.addView(header)
        val nav = HorizontalScrollView(this); val navRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(4, 4, 4, 4); setBackgroundColor(Color.WHITE) }
        val items = mutableListOf("Boshqaruv", "Mijozlar", "Arizalar")
        if (s.role == "MANAGER" || s.role == "ADMIN") items.add("Tasdiqlash")
        if (s.role == "ADMIN") items.add("Xodimlar")
        items.add("KPI")
        items.add("Chat")
        items.add("Hujjatlar")
        items.add("Hisobot")
        items.forEach { item -> val b = TextView(this).apply { text = tabLabel(item); textSize = 12f; setTextColor(if (item == tab) Palette.blue else Palette.muted); setTypeface(null, if (item == tab) Typeface.BOLD else Typeface.NORMAL); gravity = Gravity.CENTER; setPadding(pad / 2, pad, pad / 2, pad); setOnClickListener { showDashboard(item) } }; navRow.addView(b) }
        nav.addView(navRow); root.addView(nav)
        val sc = scroll(); content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(pad, pad, pad, pad) }; sc.addView(content); root.addView(sc, LinearLayout.LayoutParams(-1, 0, 1f))
        when (tab) {
            "Boshqaruv" -> dashboard()
            "Mijozlar" -> customers()
            "Arizalar" -> applications()
            "Tasdiqlash" -> approvals()
            "Xodimlar" -> users()
            "KPI" -> kpi()
            "Chat" -> chat()
            "Hujjatlar" -> documents()
            "Hisobot" -> reports()
        }
        val footer = LinearLayout(this).apply { setPadding(pad, 6, pad, 6); gravity = Gravity.CENTER_VERTICAL; setBackgroundColor(Color.WHITE) }
        footer.addView(text("Xavfsiz sessiya · ${roleName(s.role)}", 11f, Palette.muted), LinearLayout.LayoutParams(0, -2, 1f)); footer.addView(button("Chiqish", Palette.red) { db.log(s.username, "LOGOUT", "Tizimdan chiqdi"); showLogin() })
        root.addView(footer); setContentView(root)
    }
    private fun tabLabel(tab:String):String = if(language=="ru") when(tab){"Boshqaruv"->"Панель";"Mijozlar"->"Клиенты";"Arizalar"->"Заявки";"Tasdiqlash"->"Одобрение";"Xodimlar"->"Сотрудники";"Hisobot"->"Отчёты";"KPI"->"KPI";"Chat"->"Чат";"Hujjatlar"->"Документы";else->tab} else tab
    private fun roleName(role: String) = when(role) { "ADMIN" -> if(language=="ru") "Администратор" else "Administrator"; "MANAGER" -> if(language=="ru") "Менеджер" else "Menejer"; else -> if(language=="ru") "Оператор" else "Operator" }
    private fun section(title: String, sub: String = "") { content.addView(text(title, 19f, Palette.ink, true).apply { setPadding(0, 0, 0, 4) }); if (sub.isNotEmpty()) content.addView(text(sub, 12f, Palette.muted).apply { setPadding(0, 0, 0, pad) }) }
    private fun card(title: String, detail: String) { val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(pad, pad, pad, pad); background = android.graphics.drawable.GradientDrawable().apply { setColor(Color.WHITE); cornerRadius = 18f; setStroke(1, Palette.line) } }; box.addView(text(title, 15f, Palette.ink, true)); box.addView(text(detail, 12f, Palette.muted).apply { setPadding(0, 5, 0, 0) }); val lp = LinearLayout.LayoutParams(-1, -2); lp.bottomMargin = pad / 2; content.addView(box, lp) }
    private fun count(table: String, where: String = "1=1"): Int { val c = db.readableDatabase.rawQuery("SELECT COUNT(*) FROM $table WHERE $where", null); c.moveToFirst(); val n = c.getInt(0); c.close(); return n }
    private fun dashboard() {
        section("Xush kelibsiz, ${session?.fullName}", "Ish jarayonlari bo‘yicha qisqa ma’lumot")
        card("NEXUS · NETWORK", "Yagona boshqaruv tizimi · ${if(language=="uz") "O‘zbekcha" else "Русский"}")
        card("${count("customers")} ta mijoz", "Mijozlar bazasidagi jami yozuvlar")
        card("${count("applications")} ta ariza", "Barcha holatdagi arizalar")
        card("${count("applications", "status='Kutilmoqda'")} ta ko‘rib chiqilmoqda", "Menejer qarorini kutayotgan arizalar")
        card("${count("applications", "status='Tasdiqlandi'")} ta tasdiqlangan", "Ijobiy qaror qilingan arizalar")
        section("Tezkor amallar")
        content.addView(button("+ Yangi mijoz") { customerDialog() }); content.addView(button("+ Yangi ariza") { applicationDialog() })
        card("Rollar va xavfsizlik", "Har bir xodim faqat o‘z roliga ruxsat etilgan bo‘limlardan foydalanadi. Barcha asosiy amallar audit jurnaliga yoziladi.")
    }
    private fun customers() {
        section("Mijozlar bazasi", "Mijozlarni qo‘shish, ko‘rish va qidirish")
        content.addView(button("+ Mijoz qo‘shish") { customerDialog() })
        val search = field("Ism yoki telefon bo‘yicha qidirish"); content.addView(search)
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }; content.addView(list)
        fun load(q: String) { list.removeAllViews(); val c = db.readableDatabase.rawQuery("SELECT id,full_name,phone,note FROM customers WHERE full_name LIKE ? OR phone LIKE ? ORDER BY id DESC", arrayOf("%$q%", "%$q%")); while(c.moveToNext()) { val id=c.getInt(0); val name=c.getString(1); val phone=c.getString(2); val note=c.getString(3) ?: ""; val row=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(pad,pad,pad,pad); background=android.graphics.drawable.GradientDrawable().apply { setColor(Color.WHITE); cornerRadius=16f; setStroke(1,Palette.line) } }; row.addView(text(name,15f,Palette.ink,true)); row.addView(text(phone+if(note.isNotBlank()) " · $note" else "",12f,Palette.muted)); row.setOnClickListener { AlertDialog.Builder(this).setTitle(name).setMessage("Telefon: $phone\nIzoh: $note").setItems(arrayOf("Ariza yaratish", "O‘chirish")) { _, which -> if(which==0) applicationDialog(id) else { db.writableDatabase.delete("customers","id=?",arrayOf(id.toString())); db.log(session!!.username,"CUSTOMER_DELETE",name); showDashboard("Mijozlar") } }.show() }; val lp=LinearLayout.LayoutParams(-1,-2); lp.bottomMargin=pad/2; list.addView(row,lp) }; c.close(); if(list.childCount==0) list.addView(text("Hozircha mijoz topilmadi.",13f,Palette.muted)) }
        search.addTextChangedListener(SimpleWatcher { load(it) }); load("")
    }
    private fun customerDialog() {
        val name=field("F.I.Sh. (majburiy)"); val phone=field("Telefon raqami"); val note=field("Izoh")
        val box=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(pad,0,pad,0); addView(name); addView(phone); addView(note) }
        AlertDialog.Builder(this).setTitle("Yangi mijoz").setView(box).setNegativeButton("Bekor qilish",null).setPositiveButton("Saqlash") { _,_ -> if(name.text.isBlank()) { toast("F.I.Sh. kiritilishi shart"); return@setPositiveButton }; val v=ContentValues(); v.put("full_name",name.text.toString()); v.put("phone",phone.text.toString()); v.put("note",note.text.toString()); db.writableDatabase.insert("customers",null,v); db.log(session!!.username,"CUSTOMER_CREATE",name.text.toString()); showDashboard("Mijozlar") }.show()
    }
    private fun applications() {
        section("Arizalar", "Arizalar holatini kuzatish")
        content.addView(button("+ Yangi ariza") { applicationDialog() })
        val c=db.readableDatabase.rawQuery("SELECT a.id, c.full_name, a.title, a.amount, a.status, a.note FROM applications a LEFT JOIN customers c ON c.id=a.customer_id ORDER BY a.id DESC",null)
        while(c.moveToNext()) { val id=c.getInt(0); val name=c.getString(1) ?: "Noma’lum mijoz"; val title=c.getString(2); val amount=c.getString(3); val status=c.getString(4); val note=c.getString(5) ?: ""; card("#$id · $title", "$name\nSumma: ${amount.ifBlank { "Ko‘rsatilmagan" }}\nHolat: $status${if(note.isNotBlank()) "\nIzoh: $note" else ""}") }
        c.close(); if(count("applications")==0) content.addView(text("Hozircha arizalar yo‘q.",13f,Palette.muted))
    }
    private fun applicationDialog(customerId: Int? = null) {
        val customer=Spinner(this); val ids=mutableListOf<Int>(); val names=mutableListOf<String>(); val cur=db.readableDatabase.rawQuery("SELECT id,full_name FROM customers ORDER BY full_name",null); while(cur.moveToNext()){ids.add(cur.getInt(0));names.add(cur.getString(1))}; cur.close()
        if(ids.isEmpty()){ toast("Avval mijoz qo‘shing"); return }
        customer.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,names); if(customerId!=null) customer.setSelection(ids.indexOf(customerId).coerceAtLeast(0))
        val title=field("Ariza mavzusi"); val amount=field("Summa (ixtiyoriy)"); val note=field("Tavsif / izoh")
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(pad,0,pad,0);addView(text("Mijoz",13f,Palette.muted));addView(customer);addView(title);addView(amount);addView(note)}
        AlertDialog.Builder(this).setTitle("Yangi ariza").setView(box).setNegativeButton("Bekor qilish",null).setPositiveButton("Yuborish") { _,_ -> if(title.text.isBlank()){toast("Ariza mavzusini kiriting");return@setPositiveButton}; val v=ContentValues();v.put("customer_id",ids[customer.selectedItemPosition]);v.put("title",title.text.toString());v.put("amount",amount.text.toString());v.put("note",note.text.toString());v.put("status",if(session!!.role=="OPERATOR") "Kutilmoqda" else "Yangi");db.writableDatabase.insert("applications",null,v);db.log(session!!.username,"APPLICATION_CREATE",title.text.toString());showDashboard("Arizalar") }.show()
    }
    private fun approvals() {
        section("Menejer tasdiqlashi", "Kutilayotgan arizalar bo‘yicha qaror qabul qiling")
        val c=db.readableDatabase.rawQuery("SELECT a.id,c.full_name,a.title,a.amount,a.note FROM applications a LEFT JOIN customers c ON c.id=a.customer_id WHERE a.status IN ('Kutilmoqda','Yangi') ORDER BY a.id",null)
        while(c.moveToNext()) { val id=c.getInt(0); val name=c.getString(1)?:"Mijoz"; val title=c.getString(2); val amount=c.getString(3); val note=c.getString(4)?:""; val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(pad,pad,pad,pad);background=android.graphics.drawable.GradientDrawable().apply{setColor(Color.WHITE);cornerRadius=16f;setStroke(1,Palette.line)}};box.addView(text("#$id · $title",15f,Palette.ink,true));box.addView(text("$name · ${amount.ifBlank{"Summa yo‘q"}}\n$note",12f,Palette.muted));val actions=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL};actions.addView(button("Tasdiqlash",Palette.green){setStatus(id,"Tasdiqlandi")},LinearLayout.LayoutParams(0,-2,1f));actions.addView(button("Rad etish",Palette.red){setStatus(id,"Rad etildi")},LinearLayout.LayoutParams(0,-2,1f));box.addView(actions);val lp=LinearLayout.LayoutParams(-1,-2);lp.bottomMargin=pad/2;content.addView(box,lp) }
        c.close(); if(content.childCount==0 || count("applications","status IN ('Kutilmoqda','Yangi')")==0) content.addView(text("Ko‘rib chiqilishi kerak bo‘lgan ariza yo‘q.",13f,Palette.muted))
    }
    private fun setStatus(id:Int,status:String){val v=ContentValues();v.put("status",status);db.writableDatabase.update("applications",v,"id=?",arrayOf(id.toString()));db.log(session!!.username,"APPLICATION_$status","Ariza #$id");showDashboard("Tasdiqlash")}
    private fun users() {
        section("Xodimlar", "Foydalanuvchilar va rollarni boshqarish")
        content.addView(button("+ Xodim qo‘shish") { userDialog() })
        val c=db.readableDatabase.rawQuery("SELECT id,username,full_name,role,active FROM users ORDER BY id",null)
        while(c.moveToNext()){val id=c.getInt(0);val u=c.getString(1);val n=c.getString(2);val r=c.getString(3);val active=c.getInt(4)==1;val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(pad,pad,pad,pad);background=android.graphics.drawable.GradientDrawable().apply{setColor(Color.WHITE);cornerRadius=16f;setStroke(1,Palette.line)}};box.addView(text(n,15f,Palette.ink,true));box.addView(text("$u · ${roleName(r)} · ${if(active) "Faol" else "Bloklangan"}",12f,Palette.muted));if(u!="admin") box.addView(button(if(active)"Bloklash" else "Faollashtirish",Palette.red){val v=ContentValues();v.put("active",if(active)0 else 1);db.writableDatabase.update("users",v,"id=?",arrayOf(id.toString()));db.log(session!!.username,"USER_STATUS",u);showDashboard("Xodimlar")});val lp=LinearLayout.LayoutParams(-1,-2);lp.bottomMargin=pad/2;content.addView(box,lp)};c.close()
    }
    private fun userDialog(){val name=field("Xodim F.I.Sh.");val username=field("Login");val pass=field("Parol (kamida 6 belgi)");val role=Spinner(this);role.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,listOf("OPERATOR","MANAGER","ADMIN"));val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(pad,0,pad,0);addView(name);addView(username);addView(pass);addView(role)};AlertDialog.Builder(this).setTitle("Xodim qo‘shish").setView(box).setNegativeButton("Bekor",null).setPositiveButton("Saqlash"){_,_->if(name.text.isBlank()||username.text.isBlank()||pass.text.length<6){toast("Ma’lumotlarni to‘liq kiriting. Parol kamida 6 belgi.");return@setPositiveButton};try{val v=ContentValues();v.put("username",username.text.toString());v.put("password",pass.text.toString());v.put("full_name",name.text.toString());v.put("role",role.selectedItem.toString());db.writableDatabase.insertOrThrow("users",null,v);db.log(session!!.username,"USER_CREATE",username.text.toString());showDashboard("Xodimlar")}catch(e:Exception){toast("Bu login band yoki ma’lumot noto‘g‘ri")}}.show()}
    private fun kpi(){
        section("KPI va statistika", "Joriy bazadagi ko‘rsatkichlar")
        val total=count("applications"); val approved=count("applications","status='Tasdiqlandi'"); val rejected=count("applications","status='Rad etildi'"); val pending=count("applications","status IN ('Kutilmoqda','Yangi')")
        card("Mijozlar", "${count("customers")} ta ro‘yxatdan o‘tgan mijoz")
        card("Arizalar", "$total ta jami ariza")
        card("Tasdiqlash darajasi", if(total==0) "0%" else "${approved*100/total}% · $approved ta tasdiqlangan")
        card("Kutilayotgan", "$pending ta ariza")
        card("Rad etilgan", "$rejected ta ariza")
        section("Xodimlar faolligi")
        val c=db.readableDatabase.rawQuery("SELECT actor,COUNT(*) FROM audit GROUP BY actor ORDER BY COUNT(*) DESC",null)
        while(c.moveToNext()) card(c.getString(0), "${c.getInt(1)} ta amal qayd etilgan")
        c.close()
    }
    private fun chat(){
        section("Xodimlar chati", "Ushbu qurilmadagi lokal demo chat. Serverga ulangach xabarlar sinxronlanadi.")
        content.addView(button("+ Xabar yozish"){val input=field("Xabar matni");AlertDialog.Builder(this).setTitle("Yangi xabar").setView(input).setNegativeButton("Bekor",null).setPositiveButton("Yuborish"){_,_->if(input.text.isNotBlank()){val v=ContentValues();v.put("sender",session!!.fullName);v.put("role",session!!.role);v.put("message",input.text.toString());db.writableDatabase.insert("chat",null,v);db.log(session!!.username,"CHAT_SEND","Xodimlar chatiga xabar yubordi");notifyUser("Yangi chat xabari",input.text.toString());showDashboard("Chat")}}.show()})
        val c=db.readableDatabase.rawQuery("SELECT sender,role,message,created_at FROM chat ORDER BY id DESC LIMIT 100",null)
        while(c.moveToNext()) card("${c.getString(0)} · ${roleName(c.getString(1))}","${c.getString(2)}\n${c.getString(3)}")
        c.close()
    }
    private fun documents(){
        section("Fayllar va hujjatlar", "PDF, rasm va boshqa hujjatlarni qurilmadan biriktirish")
        content.addView(button("+ Hujjat yuklash"){val i=Intent(Intent.ACTION_OPEN_DOCUMENT).apply{addCategory(Intent.CATEGORY_OPENABLE);type="*/*"};startActivityForResult(i,REQ_FILE)})
        val c=db.readableDatabase.rawQuery("SELECT id,name,uri,uploaded_by,created_at FROM documents ORDER BY id DESC",null)
        while(c.moveToNext()){val id=c.getInt(0);val name=c.getString(1);val uri=c.getString(2);val by=c.getString(3);val date=c.getString(4);val b=button("Ochish: $name"){try{val i=Intent(Intent.ACTION_VIEW).apply{setDataAndType(Uri.parse(uri),contentResolver.getType(Uri.parse(uri))?:"*/*");addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)};startActivity(i)}catch(e:Exception){toast("Faylni ochish uchun mos ilova topilmadi")}};content.addView(b);card("Yuklagan: $by","$date · hujjat #$id")}
        c.close();if(count("documents")==0) card("Hozircha hujjat yo‘q","Yuklangan fayllar shu yerda ko‘rinadi")
    }
    private fun reports(){
        section("Hisobotlar va audit", "Faoliyatni kuzatish va faylga chiqarish")
        card("Jami mijozlar",count("customers").toString());card("Jami arizalar",count("applications").toString());card("Tasdiqlangan",count("applications","status='Tasdiqlandi'").toString());card("Rad etilgan",count("applications","status='Rad etildi'").toString())
        content.addView(button("Excel uchun CSV eksport",Palette.green){pendingExport="csv";val i=Intent(Intent.ACTION_CREATE_DOCUMENT).apply{addCategory(Intent.CATEGORY_OPENABLE);type="text/csv";putExtra(Intent.EXTRA_TITLE,"nexus_crm_report.csv")};startActivityForResult(i,REQ_EXPORT)})
        content.addView(button("PDF hisobot eksport",Palette.red){pendingExport="pdf";val i=Intent(Intent.ACTION_CREATE_DOCUMENT).apply{addCategory(Intent.CATEGORY_OPENABLE);type="application/pdf";putExtra(Intent.EXTRA_TITLE,"nexus_crm_report.pdf")};startActivityForResult(i,REQ_EXPORT)})
        section("Oxirgi amallar")
        val c=db.readableDatabase.rawQuery("SELECT actor,action,detail,created_at FROM audit ORDER BY id DESC LIMIT 100",null);while(c.moveToNext())card("${c.getString(1)} · ${c.getString(0)}","${c.getString(2)}\n${c.getString(3)}");c.close()
    }
    private fun createNotificationChannel(){if(Build.VERSION.SDK_INT>=26){val channel=NotificationChannel("nexus_updates","NEXUS CRM xabarlari",NotificationManager.IMPORTANCE_DEFAULT);getSystemService(NotificationManager::class.java).createNotificationChannel(channel)}}
    private fun notifyUser(title:String,message:String){try{if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS)!=android.content.pm.PackageManager.PERMISSION_GRANTED){requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS),703);return};val manager=getSystemService(NOTIFICATION_SERVICE) as NotificationManager;val builder=if(Build.VERSION.SDK_INT>=26) android.app.Notification.Builder(this,"nexus_updates") else android.app.Notification.Builder(this);builder.setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle(title).setContentText(message).setAutoCancel(true);manager.notify((System.currentTimeMillis()%100000).toInt(),builder.build())}catch(_:Exception){}}
    override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?){super.onActivityResult(requestCode,resultCode,data);if(resultCode!=RESULT_OK||data?.data==null)return;val uri=data.data!!;if(requestCode==REQ_FILE){try{contentResolver.takePersistableUriPermission(uri,Intent.FLAG_GRANT_READ_URI_PERMISSION)}catch(_:Exception){};var name="Hujjat";contentResolver.query(uri,null,null,null,null)?.use{cur->if(cur.moveToFirst()){val ix=cur.getColumnIndex(OpenableColumns.DISPLAY_NAME);if(ix>=0)name=cur.getString(ix)}};val v=ContentValues();v.put("name",name);v.put("uri",uri.toString());v.put("uploaded_by",session?.fullName?:"Noma’lum");db.writableDatabase.insert("documents",null,v);db.log(session!!.username,"DOCUMENT_UPLOAD",name);showDashboard("Hujjatlar")}else if(requestCode==REQ_EXPORT){try{val out=contentResolver.openOutputStream(uri)?:throw Exception("Fayl ochilmadi");out.use{if(pendingExport=="csv")writeCsv(it) else writePdf(it)};toast("Hisobot saqlandi");db.log(session!!.username,"REPORT_EXPORT",pendingExport)}catch(e:Exception){toast("Eksportda xato: ${e.message}")}}}
    private fun writeCsv(out:java.io.OutputStream){val w=out.writer(Charsets.UTF_8);w.write("\uFEFFID,Mijoz,Telefon,Ariza,Summa,Holat\n");val c=db.readableDatabase.rawQuery("SELECT a.id,c.full_name,c.phone,a.title,a.amount,a.status FROM applications a LEFT JOIN customers c ON c.id=a.customer_id ORDER BY a.id",null);while(c.moveToNext()){val vals=(0..5).map{c.getString(it)?:""};w.write(vals.joinToString(","){"\""+it.replace("\"","\"\"")+"\""}+"\n")};c.close();w.flush()}
    private fun writePdf(out:java.io.OutputStream){
        val doc=PdfDocument()
        val page=doc.startPage(PdfDocument.PageInfo.Builder(595,842,1).create())
        val paint=Paint().apply{color=Color.BLACK;textSize=16f}
        var y=55f
        page.canvas.drawText("NEXUS CRM - HISOBOT",40f,y,paint)
        paint.textSize=11f; y+=35f
        val customerCount=count("customers")
        val applicationCount=count("applications")
        val approvedCount=count("applications", "status='Tasdiqlandi'")
        val rejectedCount=count("applications", "status='Rad etildi'")
        val lines=listOf("Mijozlar: $customerCount", "Arizalar: $applicationCount", "Tasdiqlangan: $approvedCount", "Rad etilgan: $rejectedCount", "Sana: ${java.text.SimpleDateFormat("yyyy-MM-dd HH:mm",java.util.Locale.getDefault()).format(java.util.Date())}")
        lines.forEach{page.canvas.drawText(it,40f,y,paint);y+=24f}
        doc.finishPage(page);doc.writeTo(out);doc.close()
    }
    private fun toast(s:String){Toast.makeText(this,s,Toast.LENGTH_LONG).show()}
    override fun onDestroy(){super.onDestroy()}
}

private class NetworkLogoView(context: android.content.Context): View(context){
    private val p=Paint(Paint.ANTI_ALIAS_FLAG)
    override fun onDraw(canvas:Canvas){super.onDraw(canvas);val w=width.toFloat();val h=height.toFloat();val pts=listOf(w*.5f to h*.12f,w*.18f to h*.35f,w*.82f to h*.35f,w*.28f to h*.78f,w*.72f to h*.78f,w*.5f to h*.52f);p.color=Color.rgb(57,112,235);p.strokeWidth=(w*.045f).coerceAtLeast(2f);p.style=Paint.Style.STROKE;listOf(0 to 1,0 to 2,1 to 3,1 to 5,2 to 4,2 to 5,3 to 4,5 to 3,5 to 4).forEach{(a,b)->canvas.drawLine(pts[a].first,pts[a].second,pts[b].first,pts[b].second,p)};p.style=Paint.Style.FILL;pts.forEachIndexed{i,pt->p.color=if(i==5)Color.rgb(27,72,170) else Color.rgb(75,139,250);canvas.drawCircle(pt.first,pt.second,w*.075f,p)}}
}

private class SimpleWatcher(val changed:(String)->Unit): android.text.TextWatcher {
    override fun beforeTextChanged(s:CharSequence?,start:Int,count:Int,after:Int){}
    override fun onTextChanged(s:CharSequence?,start:Int,before:Int,count:Int){changed(s?.toString()?:"")}
    override fun afterTextChanged(s:android.text.Editable?){}
}
