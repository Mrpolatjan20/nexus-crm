# NEXUS CRM — Android + Backend starter

## Tanlangan dizayn
- Light / oq-ko‘k korporativ interfeys
- Network uslubidagi NEXUS belgisi va ilova ikonasi
- UZ/RU til almashtirish tugmasi (asosiy navigatsiya va rol nomlari tarjimasi; to‘liq tarjima keyingi iteratsiyada kengaytiriladi)

## Android imkoniyatlari (lokal prototip)
- Demo loginlar: `operator / 123456`, `manager / 123456`, `admin / 123456`
- Rollar bo‘yicha bo‘limlar
- Mijozlar va arizalar, menejer tasdiqlashi
- KPI ko‘rsatkichlari
- Lokal xodimlar chati va qurilma bildirishnomasi
- Hujjat tanlash va qurilmadagi URI ni saqlash
- CSV (Excel ochadigan) va PDF hisobot eksporti
- Audit tarixi

## Muhim cheklov
Android funksiyalarining hozirgi qismi lokal SQLite prototipidir. Chat, hujjatlar va bildirishnomalar hozircha qurilma ichida ishlaydi. Bir nechta telefonda umumiy ma’lumot, haqiqiy autentifikatsiya, serverdagi fayllar va push-bildirishnomalar uchun FastAPI backendni serverga joylashtirish va Android ilovasiga API ulash talab qilinadi. Demo parollarni real ishda ishlatmang.

## APK yig‘ish
GitHub Actions workflow `.github/workflows/main.yml`:
1. Repozitoriy bosh papkasiga `NEXUS_CRM_Starter.zip` yuklang; yoki ZIP ichidagi `android/` va `backend/` papkalarini repozitoriy ildiziga chiqaring.
2. Actions → NEXUS CRM APK Build → Run workflow.
3. `NEXUS-CRM-APK` artifactni yuklab oling.

Java va Kotlin JVM targetlari 17 qilib belgilangan.

## Backendni ishga tushirish
```bash
cd backend
python -m venv .venv
pip install -r requirements.txt
uvicorn app.main:app --host 0.0.0.0 --port 8000
```
Ishga tushgach `/health` va `/docs` endpointlarini tekshiring. Deploydan oldin `NEXUS_SECRET_KEY` ni kuchli maxfiy qiymatga almashtiring va HTTPS sozlang.
