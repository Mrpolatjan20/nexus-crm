import os
from datetime import datetime, timedelta
from typing import Optional
from fastapi import FastAPI, Depends, HTTPException, status
from fastapi.security import OAuth2PasswordBearer, OAuth2PasswordRequestForm
from jose import jwt, JWTError
from passlib.context import CryptContext
from pydantic import BaseModel, Field
from sqlalchemy import create_engine, Column, Integer, String, DateTime, ForeignKey, Text
from sqlalchemy.orm import declarative_base, sessionmaker, Session, relationship

DATABASE_URL = os.getenv("DATABASE_URL", "sqlite:///./nexus_crm.db")
SECRET_KEY = os.getenv("NEXUS_SECRET_KEY", "CHANGE_THIS_SECRET_BEFORE_DEPLOYMENT")
ALGORITHM = "HS256"
ACCESS_TOKEN_MINUTES = int(os.getenv("ACCESS_TOKEN_MINUTES", "480"))
engine = create_engine(DATABASE_URL, connect_args={"check_same_thread": False} if DATABASE_URL.startswith("sqlite") else {})
SessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False)
Base = declarative_base()
pwd = CryptContext(schemes=["bcrypt"], deprecated="auto")
oauth = OAuth2PasswordBearer(tokenUrl="/auth/login")

class User(Base):
    __tablename__ = "users"
    id = Column(Integer, primary_key=True); username = Column(String(80), unique=True, index=True, nullable=False)
    full_name = Column(String(180), nullable=False); password_hash = Column(String(255), nullable=False)
    role = Column(String(20), nullable=False, default="OPERATOR"); active = Column(Integer, default=1)
class Customer(Base):
    __tablename__ = "customers"
    id = Column(Integer, primary_key=True); full_name = Column(String(180), nullable=False)
    phone = Column(String(40), default=""); note = Column(Text, default=""); created_at = Column(DateTime, default=datetime.utcnow)
class Application(Base):
    __tablename__ = "applications"
    id = Column(Integer, primary_key=True); customer_id = Column(Integer, ForeignKey("customers.id"), nullable=False)
    title = Column(String(180), nullable=False); amount = Column(String(60), default=""); status = Column(String(30), default="Kutilmoqda")
    note = Column(Text, default=""); created_by = Column(Integer, ForeignKey("users.id")); reviewed_by = Column(Integer, ForeignKey("users.id"), nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow); updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    customer = relationship("Customer")
class Audit(Base):
    __tablename__ = "audit"
    id = Column(Integer, primary_key=True); actor_id = Column(Integer, ForeignKey("users.id")); action = Column(String(80), nullable=False)
    detail = Column(Text, default=""); created_at = Column(DateTime, default=datetime.utcnow)
Base.metadata.create_all(engine)
app = FastAPI(title="NEXUS CRM API", version="1.0.0", description="Role-based CRM backend")

def get_db():
    db = SessionLocal()
    try: yield db
    finally: db.close()
def audit(db, user, action, detail=""):
    db.add(Audit(actor_id=user.id, action=action, detail=detail)); db.commit()
def current_user(token: str = Depends(oauth), db: Session = Depends(get_db)):
    err = HTTPException(status_code=401, detail="Sessiya yaroqsiz", headers={"WWW-Authenticate": "Bearer"})
    try: payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM]); uid = int(payload.get("sub"))
    except (JWTError, TypeError, ValueError): raise err
    user = db.get(User, uid)
    if not user or not user.active: raise err
    return user
def allow(*roles):
    def check(user: User = Depends(current_user)):
        if user.role not in roles: raise HTTPException(status_code=403, detail="Bu amal uchun ruxsat yo‘q")
        return user
    return check

class CustomerIn(BaseModel): full_name: str = Field(min_length=2, max_length=180); phone: str = ""; note: str = ""
class ApplicationIn(BaseModel): customer_id: int; title: str = Field(min_length=2, max_length=180); amount: str = ""; note: str = ""
class DecisionIn(BaseModel): decision: str; note: str = ""
class UserIn(BaseModel): username: str = Field(min_length=3, max_length=80); full_name: str; password: str = Field(min_length=8); role: str

@app.get("/health")
def health(): return {"status": "ok", "service": "NEXUS CRM API"}
@app.post("/auth/bootstrap-admin")
def bootstrap_admin(data: UserIn, db: Session = Depends(get_db)):
    if db.query(User).count() > 0: raise HTTPException(403, "Admin allaqachon yaratilgan")
    if data.role != "ADMIN": raise HTTPException(400, "Birinchi foydalanuvchi ADMIN bo‘lishi kerak")
    user=User(username=data.username, full_name=data.full_name, password_hash=pwd.hash(data.password), role="ADMIN")
    db.add(user); db.commit(); db.refresh(user); return {"id":user.id,"username":user.username,"role":user.role}
@app.post("/auth/login")
def login(form: OAuth2PasswordRequestForm = Depends(), db: Session = Depends(get_db)):
    user=db.query(User).filter_by(username=form.username).first()
    if not user or not user.active or not pwd.verify(form.password,user.password_hash): raise HTTPException(401,"Login yoki parol noto‘g‘ri")
    token=jwt.encode({"sub":str(user.id),"exp":datetime.utcnow()+timedelta(minutes=ACCESS_TOKEN_MINUTES)},SECRET_KEY,algorithm=ALGORITHM)
    audit(db,user,"LOGIN","Tizimga kirdi")
    return {"access_token":token,"token_type":"bearer","user":{"id":user.id,"username":user.username,"full_name":user.full_name,"role":user.role}}
@app.get("/auth/me")
def me(user: User=Depends(current_user)): return {"id":user.id,"username":user.username,"full_name":user.full_name,"role":user.role}
@app.get("/customers")
def customers(q: str="", db: Session=Depends(get_db), user: User=Depends(current_user)):
    query=db.query(Customer)
    if q: query=query.filter((Customer.full_name.ilike(f"%{q}%")) | (Customer.phone.ilike(f"%{q}%")))
    return [{"id":x.id,"full_name":x.full_name,"phone":x.phone,"note":x.note,"created_at":x.created_at} for x in query.order_by(Customer.id.desc()).all()]
@app.post("/customers")
def create_customer(data: CustomerIn, db: Session=Depends(get_db), user: User=Depends(current_user)):
    x=Customer(**data.model_dump());db.add(x);db.commit();db.refresh(x);audit(db,user,"CUSTOMER_CREATE",x.full_name);return {"id":x.id,"full_name":x.full_name}
@app.get("/applications")
def applications(db: Session=Depends(get_db), user: User=Depends(current_user)):
    return [{"id":x.id,"customer_id":x.customer_id,"customer":x.customer.full_name,"title":x.title,"amount":x.amount,"status":x.status,"note":x.note,"created_at":x.created_at} for x in db.query(Application).order_by(Application.id.desc()).all()]
@app.post("/applications")
def create_application(data: ApplicationIn, db: Session=Depends(get_db), user: User=Depends(current_user)):
    if not db.get(Customer,data.customer_id): raise HTTPException(404,"Mijoz topilmadi")
    x=Application(**data.model_dump(),created_by=user.id,status="Kutilmoqda");db.add(x);db.commit();db.refresh(x);audit(db,user,"APPLICATION_CREATE",f"Ariza #{x.id}: {x.title}");return {"id":x.id,"status":x.status}
@app.post("/applications/{app_id}/decision")
def decision(app_id:int,data:DecisionIn,db:Session=Depends(get_db),user:User=Depends(allow("MANAGER","ADMIN"))):
    if data.decision not in ("Tasdiqlandi","Rad etildi"): raise HTTPException(400,"Qaror noto‘g‘ri")
    x=db.get(Application,app_id)
    if not x: raise HTTPException(404,"Ariza topilmadi")
    x.status=data.decision;x.reviewed_by=user.id
    if data.note: x.note=(x.note+"\nMenejer izohi: "+data.note).strip()
    db.commit();audit(db,user,"APPLICATION_DECISION",f"Ariza #{app_id}: {data.decision}");return {"id":x.id,"status":x.status}
@app.get("/users")
def users(db:Session=Depends(get_db),user:User=Depends(allow("ADMIN"))):
    return [{"id":x.id,"username":x.username,"full_name":x.full_name,"role":x.role,"active":bool(x.active)} for x in db.query(User).all()]
@app.post("/users")
def create_user(data:UserIn,db:Session=Depends(get_db),user:User=Depends(allow("ADMIN"))):
    if data.role not in ("OPERATOR","MANAGER","ADMIN"): raise HTTPException(400,"Rol noto‘g‘ri")
    if db.query(User).filter_by(username=data.username).first(): raise HTTPException(409,"Login band")
    x=User(username=data.username,full_name=data.full_name,password_hash=pwd.hash(data.password),role=data.role);db.add(x);db.commit();db.refresh(x);audit(db,user,"USER_CREATE",x.username);return {"id":x.id,"username":x.username,"role":x.role}
@app.get("/reports/summary")
def summary(db:Session=Depends(get_db),user:User=Depends(current_user)):
    return {"customers":db.query(Customer).count(),"applications":db.query(Application).count(),"pending":db.query(Application).filter(Application.status=="Kutilmoqda").count(),"approved":db.query(Application).filter(Application.status=="Tasdiqlandi").count(),"rejected":db.query(Application).filter(Application.status=="Rad etildi").count()}
@app.get("/audit")
def audit_log(db:Session=Depends(get_db),user:User=Depends(allow("MANAGER","ADMIN"))):
    rows=db.query(Audit).order_by(Audit.id.desc()).limit(200).all()
    return [{"id":x.id,"actor":db.get(User,x.actor_id).username if x.actor_id else "system","action":x.action,"detail":x.detail,"created_at":x.created_at} for x in rows]
